<?php

namespace App\Http\Libraries\JWT;

class ExpiredException extends \UnexpectedValueException
{
}
