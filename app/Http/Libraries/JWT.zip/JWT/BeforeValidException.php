<?php

namespace App\Http\Libraries\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
