<?php

namespace App\Http\Libraries\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
